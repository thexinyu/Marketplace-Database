import ShopList from "./shops/shop-list";
import ShopFormEditor from "./shops/shop-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/shops", "/"]} exact={true}>
                    <ShopList/>
                </Route>
                <Route path="/shops/:id" exact={true}>
                    <ShopFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
