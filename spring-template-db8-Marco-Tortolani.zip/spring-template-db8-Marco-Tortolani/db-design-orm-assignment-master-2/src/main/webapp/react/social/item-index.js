import ItemList from "./items/item-list";
import ItemFormEditor from "./items/item-form-editor";
const {HashRouter, Route} = window.ReactRouterDOM;
const App = () => {
    return (
        <div className="container-fluid">
            <HashRouter>
                <Route path={["/items", "/"]} exact={true}>
                    <ItemList/>
                </Route>
                <Route path="/items/:id" exact={true}>
                    <ItemFormEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
