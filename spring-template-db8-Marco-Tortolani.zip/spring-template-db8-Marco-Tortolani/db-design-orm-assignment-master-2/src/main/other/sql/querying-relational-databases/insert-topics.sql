INSERT INTO `db_design`.`topics` (`topic`) VALUES ('SPACE');
INSERT INTO `db_design`.`topics` (`topic`) VALUES ('CARS');
